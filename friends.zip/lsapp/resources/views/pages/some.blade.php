@extends('layout.layout1')
@section('content')
        <center><h1>{{$num1}}  {{$num2}}</h1></center>
@endsection  
