<?php $__env->startSection('content'); ?>
 <center><h1>Create Post</h1></center>
    <?php echo Form::open(['action'=>['PostsController@update',$post->id],'method'=>'POST','enctype'=>'multipart/form-data']); ?>

    <div class='form-group'>
        <?php echo e(Form::label('title','Title')); ?>

        <?php echo e(Form::text('title',$post->title,['class'=>'form-control','placeholder'=>'Title for your Post'])); ?>

        <br>
        <?php echo e(Form::label('body','Content')); ?>

        <?php echo e(Form::textarea('body',$post->body,['class'=>'form-control','placeholder'=>'Content of your Post'])); ?>

        <br>
        <?php echo e(Form::file('cover_image')); ?>

        <?php echo e(Form::hidden('.method','PUT')); ?>

        <?php echo e(Form::submit('submit',['class'=>'btn btn-primary'])); ?>

    </div>
    
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>