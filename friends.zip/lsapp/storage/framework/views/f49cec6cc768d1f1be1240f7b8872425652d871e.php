<?php $__env->startSection('content'); ?>
<div class="jumbotron container">    
<div class="row">
    <div class="col-md-4">
    <img class="img-circle" src="/storage/insta_images/wolf.jpg" width="200" height="160">
    </div>
    <div class="col-md-8"> 
    <h1><?php echo e(Auth::user()->name); ?></h1>
<input type="button" value="Upload ProfilePhoto" class="btn btn-primary btn-lg" onclick="func(this)" />
<script>
function func(elem){
    elem.style.display="none";    // document.getElementsByName('upload_button').style.display='none';
    document.forms['myform'].style.display='inline-block';
}
</script>
<?php echo Form::open(['name'=>'myform','action'=>'upload_profile','method'=> 'POST','enctype'=>'multipart/form-data','style'=>'display:none']); ?>

<?php echo e(Form::file('insta_image')); ?>

<br>
<?php echo e(Form::submit('Upload Photo',['class'=>'btn btn-primary btn-lg'])); ?>

</div>
</div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>