<?php $__env->startSection('content'); ?>
<center><h1><b> Posts </b></h1></center> 
<?php if(count($posts) > 0): ?>
      <div class="card">
          <ul class="list-group list-group-flush"> 
               <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="row">
                  <div class="col-md-4 col-sm-4">
                  <img style="width:50%" src="/storage/cover_images/<?php echo e($item->cover_image); ?>">
                  </div>
                  <div class="col-md-8 col-sm-8">
                  <li class="list-group-item"><a href="/posts/<?php echo e($item->id); ?>"><b><?php echo e($item->user->name); ?> -> <?php echo e($item->title); ?> </b></a><br>
                   <small>Created at :  <?php echo e($item->created_at); ?></small><br>
                  <small class="card-body"><?php echo e($item->body); ?></small></li>
               </div>
            </div>
            
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </div>
             <?php echo e($posts->links()); ?>

<?php else: ?>
   <h1> No Posts found...</h1>
<?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>