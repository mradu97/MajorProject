<?php $__env->startSection('content'); ?>
    <table align="center" class="table table-striped">
        <tr>
        <th>Title  </th>
        <th><?php echo e($post->title); ?></th>
        </tr>
        <tr>
            <td>Created By  </td>
        <td><?php echo e($post->created_at); ?></td>
        </tr>
        <tr>
            <td>Content  </td>
        <td><?php echo e($post->body); ?></td>
        </tr>
        <tr>
            <td>Cover Image  </td>
        <td><img style="width:50%" src="/storage/cover_images/<?php echo e($post->cover_image); ?>">}</td>
        </tr>
        <tr>
            <td></td>
            <td>
                <a href="/posts" class="btn btn-primary">Go back </a>
                <?php if(!Auth::guest()): ?>                    
                <?php if(Auth::user()->id == $post->user_id): ?>
                
                <a href ="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-primary">Edit </a>
                <?php echo Form::open(['action'=>['PostsController@destroy', $post->id],'method'=>'POST','style'=>'float:right']); ?>

                <?php echo e(Form::hidden('.method','DELETE')); ?>

                <?php echo e(Form::submit('Delete',['class'=> 'btn btn-danger'])); ?>

                <?php echo Form::close(); ?>

                <?php endif; ?>
                <?php endif; ?>
            </td>
        </tr>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>