<?php if(count($comments)>0): ?>
<?php $__currentLoopData = $comments->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<img src="/storage/insta_images/wolf.jpg" class="img-circle" style="width=30px; height:20px;">
<b> <?php echo e($comment->user->name); ?> : </b><?php echo e($comment->message); ?> <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo e($comments->links()); ?>    
<?php endif; ?>
