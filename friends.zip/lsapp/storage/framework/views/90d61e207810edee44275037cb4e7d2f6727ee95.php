<img src="/storage/insta_images/wolf.jpg" class="img-circle" style="width=30px; height:20px;">
<b>User name : </b>